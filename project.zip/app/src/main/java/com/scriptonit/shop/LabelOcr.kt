package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Чтение надписи на кнопке (русский текст) — подтверждает цветовой поиск: сначала
 * AnchorScan находит пятно нужного цвета, а LabelOcr читает, что на нём написано,
 * чтобы отличить «ОТМЕНА» от «КУПИТЬ» или отсеять случайное совпадение цвета,
 * которое кнопкой не является. Отдельный движок Tesseract от Ocr (тот читает цифры
 * цены на латинице, этот — заглавные русские буквы).
 */
class LabelOcr(ctx: Context) {
    private val tess = TessBaseAPI()
    val ready: Boolean

    init {
        var ok = false
        try {
            ok = hasData(ctx) && tess.init(ctx.filesDir.absolutePath, "rus")
            if (ok) {
                tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE)
                tess.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ ")
            }
        } catch (e: Exception) {
            ok = false
        }
        ready = ok
    }

    fun close() {
        try { tess.recycle() } catch (e: Exception) { }
    }

    /** Текст внутри области (прямоугольник найденной кнопки), заглавными буквами, или "" если не удалось. */
    fun readLabel(frame: Frame, band: AnchorScan.Band): String {
        if (!ready) return ""
        val x0 = band.x0.coerceIn(0, frame.w - 1)
        val y0 = band.y0.coerceIn(0, frame.h - 1)
        val w = (band.x1 - band.x0).coerceAtLeast(1).coerceAtMost(frame.w - x0)
        val h = (band.y1 - band.y0).coerceAtLeast(1).coerceAtMost(frame.h - y0)
        val crop = Bitmap.createBitmap(frame.bmp, x0, y0, w, h)
        val k = 2
        val scaled = Bitmap.createScaledBitmap(crop, crop.width * k, crop.height * k, true)
        if (scaled !== crop) crop.recycle()
        val sw = scaled.width
        val sh = scaled.height
        val px = IntArray(sw * sh)
        scaled.getPixels(px, 0, sw, 0, 0, sw, sh)
        scaled.recycle()

        var mn = 255
        var mx = 0
        for (c in px) {
            val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
            if (l < mn) mn = l
            if (l > mx) mx = l
        }
        if (mx - mn < 25) return ""
        val thr = (mn + mx) / 2
        for (i in px.indices) {
            val c = px[i]
            val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
            px[i] = if (l > thr) Color.BLACK else Color.WHITE
        }
        val pad = 16
        val out = Bitmap.createBitmap(sw + pad * 2, sh + pad * 2, Bitmap.Config.ARGB_8888)
        Canvas(out).drawColor(Color.WHITE)
        out.setPixels(px, 0, sw, pad, pad, sw, sh)
        return try {
            tess.setImage(out)
            (tess.getUTF8Text() ?: "").uppercase().trim()
        } catch (e: Exception) {
            ""
        } finally {
            out.recycle()
        }
    }

    companion object {
        private const val URL_RUS = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/rus.traineddata"

        fun dataFile(ctx: Context) = File(File(ctx.filesDir, "tessdata"), "rus.traineddata")

        fun hasData(ctx: Context): Boolean = dataFile(ctx).let { it.exists() && it.length() > 1_000_000 }

        fun download(ctx: Context): Boolean {
            return try {
                val f = dataFile(ctx)
                f.parentFile?.mkdirs()
                val tmp = File(f.parentFile, "rus.tmp")
                val conn = URL(URL_RUS).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                if (tmp.length() > 1_000_000) tmp.renameTo(f) else { tmp.delete(); false }
            } catch (e: Exception) {
                false
            }
        }
    }
}
