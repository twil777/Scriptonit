package com.scriptonit.shop

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var scriptView: TextView

    private val green = 0xFF22C55E.toInt()
    private val bg = 0xFF07110B.toInt()
    private val light = 0xFFB7F7CE.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.ensureDemo(this)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun btn(label: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(if (primary) 0xFF03130A.toInt() else light)
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(if (primary) green else 0xFF10241A.toInt())
            setStroke(dp(1), 0xFF1F7A45.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        col.addView(text("⚡ Scriptonit Shop", 28f, green, true))
        col.addView(text("Автоклики по твоим скриптам с автонастройкой под экран", 14f, light))

        statusView = text("", 15f, light).apply { setPadding(0, dp(18), 0, dp(6)) }
        col.addView(statusView)

        col.addView(btn("1. Разрешить поверх окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(btn("2. Включить службу доступности") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Найди «Scriptonit Shop» и включи")
        })
        col.addView(btn("3. Клавиатура Scriptonit (по желанию)") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(btn("Выбрать клавиатуру") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        col.addView(text("Скрипт", 18f, green, true).apply { setPadding(0, dp(22), 0, 0) })
        scriptView = text("", 14f, light)
        col.addView(scriptView)
        col.addView(btn("Выбрать скрипт") { pickScript() })
        col.addView(btn("Импорт из файла (.txt)") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }, 1
            )
        })
        col.addView(btn("Загрузить по ссылке") { askUrl() })

        col.addView(btn("▶ Запустить панель", primary = true) { startPanel() })

        col.addView(text("Мы в Telegram", 18f, green, true).apply { setPadding(0, dp(22), 0, 0) })
        col.addView(btn("Канал @Scriptonit_Shop") { open("https://t.me/Scriptonit_Shop") })
        col.addView(btn("Бот @Scriptonit_Shop_bot") { open("https://t.me/Scriptonit_Shop_bot") })

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(col)
        }
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val access = ClickService.instance != null
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val kb = imm.enabledInputMethodList.any { it.packageName == packageName }
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        statusView.text = "${mark(overlay)} Поверх окон\n${mark(access)} Служба доступности\n${mark(kb)} Клавиатура"

        val f = Store.selected(this)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        var info = "Экран: ${dm.widthPixels}×${dm.heightPixels}\n"
        info += if (f == null) "Скрипта нет" else {
            try {
                val s = ScriptParser.parse(f.readText())
                val (sx, sy) = Scaling.factors(s, dm.widthPixels, dm.heightPixels)
                "Выбран: ${f.nameWithoutExtension}\n" +
                    if (s.refW > 0) "Автонастройка: ${s.refW}×${s.refH} → масштаб ×%.2f / ×%.2f".format(sx, sy)
                    else "Нет строки ref — координаты берутся как есть"
            } catch (e: Exception) {
                "Выбран: ${f.nameWithoutExtension}\n⚠️ ${e.message}"
            }
        }
        scriptView.text = info
    }

    private fun pickScript() {
        val files = Store.list(this)
        AlertDialog.Builder(this)
            .setTitle("Скрипт")
            .setItems(files.map { it.nameWithoutExtension }.toTypedArray()) { _, i ->
                Store.select(this, files[i])
                refresh()
            }
            .show()
    }

    private fun askUrl() {
        val input = EditText(this).apply { hint = "https://…/script.txt" }
        AlertDialog.Builder(this)
            .setTitle("Ссылка на скрипт")
            .setView(input)
            .setPositiveButton("Загрузить") { _, _ -> download(input.text.toString().trim()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun download(url: String) {
        if (!url.startsWith("https://")) {
            toast("Нужна ссылка https://")
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val body = conn.inputStream.use { it.readBytes() }
                if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
                val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "script" }
                runOnUiThread {
                    try {
                        Store.save(this, name, String(body, Charsets.UTF_8))
                        toast("Скрипт загружен")
                        refresh()
                    } catch (e: Exception) {
                        toast(e.message ?: "Ошибка в скрипте")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось загрузить: ${e.message}") }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            var name = "script"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
            val body = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
            Store.save(this, name, String(body, Charsets.UTF_8))
            toast("Скрипт импортирован")
            refresh()
        } catch (e: Exception) {
            toast(e.message ?: "Не удалось прочитать файл")
        }
    }

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала разреши показ поверх окон")
            return
        }
        if (ClickService.instance == null) {
            toast("Включи службу доступности")
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
