package com.scriptonit.shop

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private val bg = 0xFF060D09.toInt()
    private val card = 0xFF0C1811.toInt()
    private val line = 0xFF1A3626.toInt()
    private val green = 0xFF22C55E.toInt()
    private val textMain = 0xFFE6FFEE.toInt()
    private val textDim = 0xFF7FA38C.toInt()

    private lateinit var dotOverlay: TextView
    private lateinit var dotAccess: TextView
    private lateinit var dotKbOn: TextView
    private lateinit var dotKbDefault: TextView
    private lateinit var dotOcr: TextView
    private lateinit var ocrAction: Button
    private lateinit var modeView: TextView
    private lateinit var screenView: TextView
    private lateinit var statBids: TextView
    private lateinit var statSnake: TextView
    private val fields = LinkedHashMap<String, EditText>()
    private var ocrLoading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.ensureDemo(this)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        loadOcrData()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- интерфейс ----------

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun cardBg() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF102219.toInt(), 0xFF0A140E.toInt())
    ).apply {
        cornerRadius = dp(20).toFloat()
        setStroke(dp(1), line)
    }

    private fun cardView(title: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(14), dp(16), dp(10))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
        if (title != null) addView(label(title, 12f, textDim, true).apply {
            letterSpacing = 0.12f
            setPadding(0, 0, 0, dp(6))
        })
    }

    private fun smallBtn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setTextColor(green)
        background = rounded(0xFF10241A.toInt(), 0xFF1F7A45.toInt(), 12)
        setOnClickListener { onClick() }
    }

    private fun wideBtn(text: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) 0xFF03130A.toInt() else textMain)
        background = if (primary) {
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF16A34A.toInt(), 0xFF34D399.toInt())
            ).apply { cornerRadius = dp(16).toFloat() }
        } else {
            rounded(0xFF10241A.toInt(), 0xFF1F7A45.toInt(), 16)
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    /** Строка шага: индикатор, название, кнопка действия. */
    private fun step(parent: LinearLayout, title: String, action: Button): TextView {
        val dot = label("○", 20f, textDim).apply { setPadding(0, 0, dp(12), 0) }
        val name = label(title, 15f, textMain).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            addView(dot)
            addView(name)
            addView(action)
        })
        return dot
    }

    private fun field(key: String, hint: String, def: String): EditText = EditText(this).apply {
        setText(BotPrefs.raw(this@MainActivity, key, def))
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(textMain)
        setHintTextColor(textDim)
        textSize = 15f
        background = rounded(0xFF08130C.toInt(), line, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        fields[key] = this
    }

    private fun labeled(title: String, et: EditText): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        addView(label(title, 12f, textDim))
        addView(et)
    }

    private fun pair(a: LinearLayout, b: LinearLayout) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a)
        addView(b)
    }

    private fun statCard(title: String, value: TextView): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), dp(10), dp(4), 0)
        }
        addView(label(title, 12f, textDim))
        addView(value)
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(32))
        }

        // шапка
        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_START
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        })

        statBids = label("0", 24f, green, true)
        statSnake = label("0", 24f, green, true)
        col.addView(pair(statCard("Ставок всего", statBids), statCard("Рекорд змейки", statSnake)))

        // подготовка
        val prep = cardView("ПОДГОТОВКА")
        dotOverlay = step(prep, "Поверх других окон", smallBtn("Разрешить") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        dotAccess = step(prep, "Служба доступности", smallBtn("Включить") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Найди Scriptonit Shop и включи")
        })
        dotKbOn = step(prep, "Клавиатура Scriptonit", smallBtn("Включить") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        dotKbDefault = step(prep, "Клавиатура по умолчанию", smallBtn("Выбрать") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        ocrAction = smallBtn("Скачать") { loadOcrData() }
        dotOcr = step(prep, "Распознавание цен", ocrAction)
        prep.addView(label("Запись экрана запросится при запуске.", 12f, textDim).apply { setPadding(0, dp(4), 0, dp(4)) })
        col.addView(prep)

        // рынок
        val market = cardView("РЫНОК")
        market.addView(pair(labeled("Цена от, G", field("min", "10", "10")), labeled("Цена до, G", field("max", "99999", "99999"))))
        market.addView(pair(labeled("Шаг, G", field("step", "0.01", "0.01")), labeled("Запас до лота, G", field("gap", "0.02", "0.02"))))
        market.addView(pair(labeled("Обновление, с", field("refresh", "5", "5")), labeled("Отмена через, с", field("cancel", "2.5", "2.5"))))
        market.addView(pair(labeled("Работать, мин", field("minutes", "119", "119")), labeled("Лимит ставок", field("bids", "300", "300"))))
        screenView = label("", 12f, textDim).apply { setPadding(dp(4), dp(8), 0, dp(4)) }
        market.addView(screenView)
        col.addView(market)

        // режим и скрипты
        val mode = cardView("РЕЖИМ")
        modeView = label("", 15f, textMain).apply { setPadding(0, 0, 0, dp(4)) }
        mode.addView(modeView)
        mode.addView(wideBtn("Маркет") { Store.setMarket(this@MainActivity); refresh() })
        mode.addView(wideBtn("Свой скрипт") { pickScript() })
        mode.addView(wideBtn("Импорт из файла") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }, 1
            )
        })
        mode.addView(wideBtn("Загрузить по ссылке") { askUrl() })
        col.addView(mode)

        val extras = cardView("ПЛЮШКИ")
        extras.addView(wideBtn("🐍  Змейка") { startActivity(Intent(this, SnakeActivity::class.java)) })
        col.addView(extras)

        col.addView(wideBtn("▶  Запустить", primary = true) { startPanel() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(18)
            setPadding(0, dp(14), 0, dp(14))
        })

        col.addView(pair(
            LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(wideBtn("Канал") { open("https://t.me/Scriptonit_Shop") }.apply {
                    (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(4)
                })
            },
            LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(wideBtn("Бот") { open("https://t.me/Scriptonit_Shop_bot") }.apply {
                    (layoutParams as LinearLayout.LayoutParams).leftMargin = dp(4)
                })
            }
        ))

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(col)
        }
    }

    // ---------- состояние ----------

    private fun setDot(d: TextView, ok: Boolean) {
        d.text = if (ok) "●" else "○"
        d.setTextColor(if (ok) green else textDim)
    }

    private fun refresh() {
        statBids.text = Stats.bids(this).toString()
        statSnake.text = Stats.snakeBest(this).toString()
        setDot(dotOverlay, Settings.canDrawOverlays(this))
        setDot(dotAccess, ClickService.instance != null)
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        setDot(dotKbOn, imm.enabledInputMethodList.any { it.packageName == packageName })
        val def = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        setDot(dotKbDefault, def.startsWith(packageName))
        val hasData = Ocr.hasData(this)
        setDot(dotOcr, hasData)
        ocrAction.text = when {
            ocrLoading -> "Загрузка…"
            hasData -> "Готово"
            else -> "Скачать"
        }

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        val w = maxOf(dm.widthPixels, dm.heightPixels)
        val h = minOf(dm.widthPixels, dm.heightPixels)
        screenView.text = "Экран ${w}×${h}  ·  автонастройка ×%.2f / ×%.2f".format(
            w / Profile.REF_W.toFloat(), h / Profile.REF_H.toFloat()
        )

        modeView.text = if (Store.mode(this) == "market") {
            "Сейчас: Маркет"
        } else {
            "Сейчас: " + (Store.selected(this)?.nameWithoutExtension ?: "нет скрипта")
        }
    }

    private fun loadOcrData() {
        if (Ocr.hasData(this) || ocrLoading) return
        ocrLoading = true
        refresh()
        Thread {
            val ok = Ocr.download(this)
            runOnUiThread {
                ocrLoading = false
                if (!ok) toast("Не удалось скачать данные. Проверь интернет и нажми «Скачать»")
                refresh()
            }
        }.start()
    }

    // ---------- скрипты ----------

    private fun pickScript() {
        val files = Store.list(this)
        AlertDialog.Builder(this)
            .setTitle("Скрипт")
            .setItems(files.map { it.nameWithoutExtension }.toTypedArray()) { _, i ->
                Store.select(this, files[i])
                refresh()
            }
            .show()
    }

    private fun askUrl() {
        val input = EditText(this).apply { hint = "https://…/script.txt" }
        AlertDialog.Builder(this)
            .setTitle("Ссылка на скрипт")
            .setView(input)
            .setPositiveButton("Загрузить") { _, _ -> download(input.text.toString().trim()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun download(url: String) {
        if (!url.startsWith("https://")) {
            toast("Нужна ссылка https://")
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val body = conn.inputStream.use { it.readBytes() }
                if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
                val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "script" }
                runOnUiThread {
                    try {
                        Store.save(this, name, String(body, Charsets.UTF_8))
                        toast("Скрипт загружен")
                        refresh()
                    } catch (e: Exception) {
                        toast(e.message ?: "Ошибка в скрипте")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось загрузить: ${e.message}") }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            1 -> importFile(data)
            2 -> {
                val svc = Intent(this, OverlayService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(svc)
                moveTaskToBack(true)
            }
        }
    }

    private fun importFile(data: Intent) {
        val uri = data.data ?: return
        try {
            var name = "script"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
            val body = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
            Store.save(this, name, String(body, Charsets.UTF_8))
            toast("Скрипт импортирован")
            refresh()
        } catch (e: Exception) {
            toast(e.message ?: "Не удалось прочитать файл")
        }
    }

    // ---------- запуск ----------

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) { toast("Разреши показ поверх окон"); return }
        if (ClickService.instance == null) { toast("Включи службу доступности"); return }
        if (Store.mode(this) == "market" && !Ocr.hasData(this)) {
            toast("Данные распознавания ещё не загружены")
            loadOcrData()
            return
        }
        BotPrefs.save(this, fields.mapValues { it.value.text.toString().trim() })
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
