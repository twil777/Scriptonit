package com.scriptonit.shop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var playBtn: TextView
    private lateinit var nameView: TextView
    private val runner = ScriptRunner()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runner.stop()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("panel", "Панель Scriptonit", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "panel")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Scriptonit Shop")
            .setContentText("Панель запущена")
            .setOngoing(true)
            .build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chip(text: String, size: Float = 18f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFB7F7CE.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                setColor(0xEE07110B.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF22C55E.toInt())
            }
        }
        val handle = chip("⚡", 20f)
        nameView = chip("", 13f)
        playBtn = chip("▶", 22f).apply { setTextColor(0xFF22C55E.toInt()) }
        val close = chip("✕", 16f)

        root.addView(handle)
        root.addView(nameView)
        root.addView(playBtn)
        root.addView(close)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        // перетаскивание за значок ⚡
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, params)
                }
            }
            true
        }
        playBtn.setOnClickListener { toggle() }
        close.setOnClickListener { stopSelf() }

        wm.addView(root, params)
        panel = root
        refresh()
    }

    private fun refresh() {
        nameView.text = Store.selected(this)?.nameWithoutExtension ?: "нет скрипта"
        playBtn.text = if (runner.running) "■" else "▶"
    }

    private fun toggle() {
        if (runner.running) {
            runner.stop()
            refresh()
            return
        }
        val svc = ClickService.instance
        if (svc == null) {
            toast("Включи службу доступности в приложении")
            return
        }
        val file = Store.selected(this)
        if (file == null) {
            toast("Выбери скрипт в приложении")
            return
        }
        val script = try {
            ScriptParser.parse(file.readText())
        } catch (e: Exception) {
            toast(e.message ?: "Ошибка в скрипте")
            return
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        runner.start(svc, script, dm.widthPixels, dm.heightPixels) { refresh() }
        refresh()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
