package com.scriptonit.shop

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect

data class Pt(val x: Int, val y: Int)

/** Кадр экрана: bitmap может быть шире экрана из-за выравнивания строк, поэтому w и h хранятся отдельно. */
class Frame(val bmp: Bitmap, val w: Int, val h: Int)

/**
 * Профиль экрана маркета Standoff 2. Снят на экране 2412×1084 (альбом).
 * На другом разрешении все точки и области пересчитываются пропорционально (автонастройка).
 */
object Profile {
    const val REF_W = 2412
    const val REF_H = 1084

    // Области чтения цен (число без значка G)
    val REQUEST_PRICE = Rect(1600, 160, 2010, 212)
    val LOT_PRICE = Rect(1600, 482, 2010, 533)

    // Кнопки
    val ORDER_PAGE = Pt(2223, 187)     // «Заказать» на странице предмета
    val PRICE_FIELD = Pt(1158, 444)    // поле цены в окне запроса
    val DIALOG_ORDER = Pt(1206, 760)   // «Заказать» в окне запроса
    val DIALOG_CLOSE = Pt(1813, 286)   // крестик окна запроса
    val MY_REQUESTS = Pt(734, 402)     // галочка «Только мои запросы»
    val CANCEL = Pt(2223, 300)         // отмена своего запроса (уточнить по скрину)
    const val OK_BAR_X = 2300          // кнопка OK на белой панели ввода

    // Контрольные точки для определения экрана
    private val ORDER_PROBE = Pt(2100, 165)
    private val DIALOG_PROBE = Pt(1100, 740)
    private val KEYBOARD_PROBE = Pt(500, 450)

    fun mapX(f: Frame, x: Int) = (x.toLong() * f.w / REF_W).toInt().coerceIn(0, f.w - 1)
    fun mapY(f: Frame, y: Int) = (y.toLong() * f.h / REF_H).toInt().coerceIn(0, f.h - 1)

    fun scaled(f: Frame, r: Rect): Rect {
        val l = mapX(f, r.left)
        val t = mapY(f, r.top)
        return Rect(l, t, mapX(f, r.right).coerceAtLeast(l + 1), mapY(f, r.bottom).coerceAtLeast(t + 1))
    }

    private fun px(f: Frame, p: Pt): Int = f.bmp.getPixel(mapX(f, p.x), mapY(f, p.y))

    private fun bright(c: Int) = Color.red(c) > 200 && Color.green(c) in 120..215 && Color.blue(c) < 120

    /** Страница предмета: кнопка «Заказать» ярко-оранжевая. */
    fun isPage(f: Frame) = bright(px(f, ORDER_PROBE))

    /** Окно «Запрос на покупку»: фон затемнён, а кнопка внутри окна яркая. */
    fun isDialog(f: Frame): Boolean {
        val top = px(f, ORDER_PROBE)
        return Color.red(top) < 150 && bright(px(f, DIALOG_PROBE))
    }

    /** Открыто поле ввода (белая панель над клавиатурой). */
    fun isKeyboard(f: Frame): Boolean {
        val c = px(f, KEYBOARD_PROBE)
        return Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
    }

    /** Центр белой панели ввода по вертикали в пикселях экрана или null. */
    fun inputBarY(f: Frame): Int? {
        val x = mapX(f, 500)
        var first = -1
        var last = -1
        var y = 0
        while (y < f.h) {
            val c = f.bmp.getPixel(x, y)
            val white = Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
            if (white) {
                if (first < 0) first = y
                last = y
            } else if (first >= 0 && y - last > 12) {
                break
            }
            y += 3
        }
        return if (first >= 0 && last - first > 40) (first + last) / 2 else null
    }

    /** Быстрый отпечаток области: меняется, когда меняется текст. Нужен, чтобы не гонять распознавание зря. */
    fun regionHash(f: Frame, region: Rect): Int {
        val r = scaled(f, region)
        var hash = 17
        var y = r.top
        while (y < r.bottom) {
            var x = r.left
            while (x < r.right) {
                val c = f.bmp.getPixel(x, y)
                val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                hash = hash * 31 + (lum shr 5)
                x += 2
            }
            y += 2
        }
        return hash
    }
}
