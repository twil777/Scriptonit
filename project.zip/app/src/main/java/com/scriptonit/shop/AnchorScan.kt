юpackage com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs

object AnchorScan {
    data class Band(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
        val w get() = x1 - x0
        val h get() = y1 - y0
        val cx get() = (x0 + x1) / 2
        val cy get() = (y0 + y1) / 2
    }

    val ORDER_COLOR = Triple(242, 163, 52)
    val ACTION_COLOR = Triple(131, 154, 202)
    private const val TOL = 46

    private fun matches(c: Int, t: Triple<Int, Int, Int>): Boolean {
        val d = abs(Color.red(c) - t.first) + abs(Color.green(c) - t.second) + abs(Color.blue(c) - t.third)
        return d < TOL
    }

    private fun clusters(frame: Frame, target: Triple<Int, Int, Int>, step: Int, region: Rect?, logger: ((String) -> Unit)? = null): List<Band> {
        val bmp = frame.bmp
        val rx0 = (region?.left ?: 0).coerceIn(0, frame.w - 1)
        val ry0 = (region?.top ?: 0).coerceIn(0, frame.h - 1)
        val rx1 = (region?.right ?: frame.w).coerceIn(rx0 + 1, frame.w)
        val ry1 = (region?.bottom ?: frame.h).coerceIn(ry0 + 1, frame.h)

        val cells = HashSet<Long>()
        fun key(gx: Int, gy: Int) = (gx.toLong() shl 20) or (gy.toLong() and 0xFFFFF)
        var y = ry0
        while (y < ry1) {
            var x = rx0
            while (x < rx1) {
                if (matches(bmp.getPixel(x, y), target)) cells.add(key(x / step, y / step))
                x += step
            }
            y += step
        }
        
        if (cells.size < 6) {
            logger?.invoke("Скан: найдено ячеек цвета < 6 (${cells.size})")
            return emptyList()
        }

        val visited = HashSet<Long>()
        val result = ArrayList<Band>()
        var maxW = 0
        var maxH = 0
        
        for (start in cells) {
            if (start in visited) continue
            val stack = ArrayDeque<Long>()
            stack.addLast(start); visited.add(start)
            var minGx = Int.MAX_VALUE; var minGy = Int.MAX_VALUE; var maxGx = Int.MIN_VALUE; var maxGy = Int.MIN_VALUE
            var size = 0
            while (stack.isNotEmpty()) {
                val c = stack.removeLast()
                val gx = (c shr 20).toInt()
                val gy = (c and 0xFFFFF).toInt()
                size++
                if (gx < minGx) minGx = gx
                if (gx > maxGx) maxGx = gx
                if (gy < minGy) minGy = gy
                if (gy > maxGy) maxGy = gy
                for (dx in -2..2) for (dy in -2..2) {
                    val n = key(gx + dx, gy + dy)
                    if (n in cells && n !in visited) {
                        visited.add(n); stack.addLast(n)
                    }
                }
            }
            if (size < 6) continue
            
            val x0 = minGx * step; val y0 = minGy * step
            val x1 = maxGx * step; val y1 = maxGy * step
            val w = x1 - x0; val h = y1 - y0
            
            if (w > maxW) maxW = w
            if (h > maxH) maxH = h
            
            if (w < frame.w * 0.025f) continue
            if (w > frame.w * 0.38f) continue
            if (h < frame.h * 0.01f) continue
            if (h > frame.h * 0.2f) continue
            
            result.add(Band(x0, y0, x1, y1))
        }
        
        if (result.isEmpty()) {
            logger?.invoke("Скан: отброшены все. Макс. размер был W=$maxW (надо >${(frame.w * 0.025f).toInt()}), H=$maxH (надо >${(frame.h * 0.01f).toInt()})")
        } else {
            logger?.invoke("Скан: найдено пятен: ${result.size}. Самое большое: W=$maxW, H=$maxH")
        }
        
        return result
    }

    fun scan(frame: Frame, target: Triple<Int, Int, Int>, step: Int = 5, region: Rect? = null, logger: ((String) -> Unit)? = null): Band? =
        clusters(frame, target, step, region, logger).maxByOrNull { it.w.toLong() * it.h }

    fun scanBelow(frame: Frame, target: Triple<Int, Int, Int>, above: Band, maxGapPx: Int, step: Int = 5): Band? =
        clustersBelow(frame, target, above, maxGapPx, step).firstOrNull()

    fun clustersBelow(frame: Frame, target: Triple<Int, Int, Int>, above: Band, maxGapPx: Int, step: Int = 5): List<Band> {
        val pad = above.w / 6
        val region = Rect(above.x0 - pad, above.y1, above.x1 + pad, (above.y1 + maxGapPx).coerceAtMost(frame.h))
        return clusters(frame, target, step, region).sortedBy { it.y0 }
    }

    fun probe(frame: Frame, band: Band, target: Triple<Int, Int, Int>): Boolean =
        band.cx in 0 until frame.w && band.cy in 0 until frame.h && matches(frame.bmp.getPixel(band.cx, band.cy), target)

    fun priceRegionLeftOf(button: Band): Rect {
        val l = (button.x0 - button.w * 0.58f).toInt()
        val r = (button.x0 - button.w * 0.03f).toInt()
        return Rect(l.coerceAtLeast(0), button.y0, r.coerceAtLeast(l + 10), button.y1)
    }

    fun offsetFrom(band: Band, dxW: Float, dyW: Float): android.graphics.Point =
        android.graphics.Point((band.cx + dxW * band.w).toInt(), (band.cy + dyW * band.w).toInt())
}
