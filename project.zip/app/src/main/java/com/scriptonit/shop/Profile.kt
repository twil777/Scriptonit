package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect

data class Pt(val x: Int, val y: Int)

/** Кадр экрана: bitmap может быть шире экрана из-за выравнивания строк, поэтому w и h хранятся отдельно. */
class Frame(val bmp: android.graphics.Bitmap, val w: Int, val h: Int)

object Profile {
    private const val PRICE_FIELD_DXW = -0.122f
    private const val PRICE_FIELD_DYW = -0.792f
    private const val CLOSE_DXW = 1.524f
    private const val CLOSE_DYW = -1.190f

    var orderBand: AnchorScan.Band? = null; private set
    var actionBand: AnchorScan.Band? = null; private set
    var dialogOrderBand: AnchorScan.Band? = null; private set

    private fun verifyLabel(f: Frame, band: AnchorScan.Band, expectedContains: Array<String>, labelOcr: LabelOcr?): Boolean {
        if (labelOcr == null || !labelOcr.ready) return true
        val text = labelOcr.readLabel(f, band)
        if (text.isEmpty()) return true
        return expectedContains.any { text.contains(it) }
    }

    /** Поиск кнопки «Заказать» на СТРАНИЦЕ */
    private fun rescanPage(f: Frame, labelOcr: LabelOcr? = null) {
        // РАСШИРЕНА ЗОНА ПОИСКА (с 50% до 35% от левого края), чтобы точно захватить кнопку
        val region = Rect((f.w * 0.35f).toInt(), 0, f.w, f.h)
        var order = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = region)
        if (order != null && !verifyLabel(f, order, arrayOf("ЗАКАЗ"), labelOcr)) order = null
        orderBand = order
        if (order == null) { actionBand = null; return }

        val candidates = AnchorScan.clustersBelow(f, AnchorScan.ACTION_COLOR, order, maxGapPx = (f.h * 0.22f).toInt())
        
        // Ищем ТОЛЬКО "ОТМЕН". Убрали "КУП", чтобы бот никогда не нажал на покупку лота.
        actionBand = if (labelOcr?.ready == true) {
            candidates.firstOrNull { verifyLabel(f, it, arrayOf("ОТМЕН"), labelOcr) } ?: candidates.firstOrNull()
        } else {
            candidates.firstOrNull()
        }
    }

    private fun rescanDialog(f: Frame, labelOcr: LabelOcr? = null): AnchorScan.Band? {
        var found = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = null)
        if (found != null && !verifyLabel(f, found, arrayOf("ЗАКАЗ"), labelOcr)) found = null
        if (found != null) dialogOrderBand = found
        return found ?: dialogOrderBand
    }

    fun isPage(f: Frame, labelOcr: LabelOcr? = null): Boolean {
        val b = orderBand
        if (b != null && AnchorScan.probe(f, b, AnchorScan.ORDER_COLOR)) return true
        rescanPage(f, labelOcr)
        return orderBand != null
    }

    fun isKeyboard(f: Frame): Boolean = inputBarY(f) != null

    fun isDialog(f: Frame): Boolean = !isPage(f) && !isKeyboard(f)

    fun orderTap(f: Frame): Pt? = orderBand?.let { Pt(it.cx, it.cy) }
    
    fun actionTap(f: Frame): Pt? = actionBand?.let { Pt(it.cx, it.cy) }

    fun requestPriceRegion(f: Frame): Rect? = orderBand?.let { AnchorScan.priceRegionLeftOf(it) }
    fun lotPriceRegion(f: Frame): Rect? = actionBand?.let { AnchorScan.priceRegionLeftOf(it) }

    /** Галочка «Только мои запросы». Ищем темный квадрат в левой половине. */
    fun myRequestsTap(f: Frame): Pt? {
        val order = orderBand ?: return null
        val region = Rect(0, order.y0 - (order.h / 2), f.w / 2, order.y1 + (f.h * 0.15f).toInt())
        val darkBox = AnchorScan.scan(f, Triple(40, 40, 40), step = 4, region = region)
        return darkBox?.let { Pt(it.cx, it.cy) }
    }

    fun dialogConfirmTap(f: Frame, labelOcr: LabelOcr? = null): Pt? = rescanDialog(f, labelOcr)?.let { Pt(it.cx, it.cy) }

    fun dialogPriceFieldTap(f: Frame, labelOcr: LabelOcr? = null): Pt? {
        val b = dialogOrderBand ?: rescanDialog(f, labelOcr) ?: return null
        val p = AnchorScan.offsetFrom(b, PRICE_FIELD_DXW, PRICE_FIELD_DYW)
        return Pt(p.x, p.y)
    }

    fun dialogCloseTap(f: Frame, labelOcr: LabelOcr? = null): Pt? {
        val b = dialogOrderBand ?: rescanDialog(f, labelOcr) ?: return null
        val p = AnchorScan.offsetFrom(b, CLOSE_DXW, CLOSE_DYW)
        return Pt(p.x, p.y)
    }

    fun resetDialogCache() {
        dialogOrderBand = null
    }

    fun reset() {
        orderBand = null
        actionBand = null
        dialogOrderBand = null
    }

    fun requestHash(f: Frame): Int? = requestPriceRegion(f)?.let { regionHash(f, it) }

    fun regionHash(f: Frame, r: Rect): Int {
        var hash = 17
        var y = r.top
        while (y < r.bottom) {
            var x = r.left
            while (x < r.right) {
                val c = f.bmp.getPixel(x.coerceIn(0, f.w - 1), y.coerceIn(0, f.h - 1))
                val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                hash = hash * 31 + (lum shr 5)
                x += 2
            }
            y += 2
        }
        return hash
    }

    fun inputBar(f: Frame): Triple<Int, Int, Int>? {
        val x = (f.w * 0.25f).toInt().coerceIn(0, f.w - 1)
        var first = -1
        var last = -1
        var y = 0
        while (y < f.h) {
            val c = f.bmp.getPixel(x, y)
            val white = Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
            if (white) {
                if (first < 0) first = y
                last = y
            } else if (first >= 0 && y - last > 12) {
                break
            }
            y += 3
        }
        if (first < 0 || last - first <= f.h * 0.03f) return null
        val rowY = (first + last) / 2
        var left = -1
        var right = -1
        var xx = 0
        while (xx < f.w) {
            val c = f.bmp.getPixel(xx, rowY)
            val white = Color.red(c) > 235 && Color.green(c) > 235 && Color.blue(c) > 235
            if (white) {
                if (left < 0) left = xx
                right = xx
            }
            xx += 4
        }
        return Triple(rowY, if (left >= 0) left else 0, if (right >= 0) right else f.w - 1)
    }

    fun inputBarY(f: Frame): Int? = inputBar(f)?.first
}
