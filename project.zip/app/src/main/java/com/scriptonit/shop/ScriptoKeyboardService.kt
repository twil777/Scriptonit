package com.scriptonit.shop

import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

/** Простая собственная клавиатура: EN/RU, цифры, Shift, пробел, Enter. */
class ScriptoKeyboardService : InputMethodService() {

    private var russian = false
    private var shift = false
    private lateinit var container: LinearLayout

    private val en = listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val ru = listOf("1234567890", "йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF07110B.toInt())
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        render()
        return container
    }

    private fun key(label: String, weight: Float = 1f, accent: Boolean = false, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 17f
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            setTextColor(if (accent) 0xFF03130A.toInt() else 0xFFB7F7CE.toInt())
            background = GradientDrawable().apply {
                cornerRadius = dp(9).toFloat()
                setColor(if (accent) 0xFF22C55E.toInt() else 0xFF10241A.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            setOnClickListener { onClick() }
        }

    private fun row(vararg keys: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        keys.forEach { addView(it) }
    }

    private fun type(ch: String) {
        currentInputConnection?.commitText(if (shift) ch.uppercase() else ch, 1)
        if (shift) {
            shift = false
            render()
        }
    }

    private fun render() {
        container.removeAllViews()
        val layout = if (russian) ru else en
        for (line in layout) {
            val keys = line.map { c ->
                val s = c.toString()
                key(if (shift) s.uppercase() else s) { type(s) }
            }
            container.addView(row(*keys.toTypedArray()))
        }
        container.addView(
            row(
                key(if (shift) "⇧" else "⬆", 1.3f, accent = shift) { shift = !shift; render() },
                key(if (russian) "RU" else "EN", 1.3f) { russian = !russian; render() },
                key(",") { type(",") },
                key("пробел", 4f) { currentInputConnection?.commitText(" ", 1) },
                key(".") { type(".") },
                key("⌫", 1.3f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) },
                key("⏎", 1.3f, accent = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }
            )
        )
    }
}
