package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect

data class Pt(val x: Int, val y: Int)

/** Кадр экрана: bitmap может быть шире экрана из-за выравнивания строк, поэтому w и h хранятся отдельно. */
class Frame(val bmp: android.graphics.Bitmap, val w: Int, val h: Int)

/**
 * Определение элементов интерфейса маркета без привязки к конкретному разрешению или
 * аспекту экрана. Кнопка «Заказать» и область цены находятся цветовым поиском (AnchorScan)
 * заново на каждом полном обновлении страницы; между обновлениями используется быстрая
 * проверка по уже найденным координатам — так же надёжно, но без лишней нагрузки.
 *
 * Для окна «Запрос на покупку» (поле ввода цены, кнопки «Заказать»/крестик внутри окна)
 * готового цветового ориентира нет — эти точки заданы как доля ширины/высоты экрана,
 * подобранная по реальным скриншотам с телефона и ПК. Это менее универсально, чем
 * цветовой поиск, и может потребовать подстройки под сильно отличающийся интерфейс.
 */
object Profile {
    // --- доли экрана для элементов внутри модального окна (см. пояснение выше) ---
    const val DIALOG_PRICE_FIELD_FX = 0.480f
    const val DIALOG_PRICE_FIELD_FY = 0.410f
    const val DIALOG_ORDER_FX = 0.500f
    const val DIALOG_ORDER_FY = 0.700f
    const val DIALOG_CLOSE_FX = 0.751f
    const val DIALOG_CLOSE_FY = 0.264f
    const val MY_REQUESTS_FX = 0.304f
    const val MY_REQUESTS_FY = 0.371f
    const val OK_BAR_FX = 0.954f

    fun pt(f: Frame, fx: Float, fy: Float) = Pt((fx * f.w).toInt(), (fy * f.h).toInt())

    // --- состояние, обновляемое цветовым поиском ---
    var orderBand: AnchorScan.Band? = null; private set
    var actionBand: AnchorScan.Band? = null; private set

    /** Полный поиск кнопки «Заказать» и первой синей кнопки под ней. Делать нечасто (дорого). */
    fun rescan(f: Frame) {
        val order = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5)
        orderBand = order
        actionBand = if (order != null) AnchorScan.scanBelow(f, AnchorScan.ACTION_COLOR, order, maxGapPx = (f.h * 0.22f).toInt()) else null
    }

    /** Страница предмета: кнопка «Заказать» видна (ярко-оранжевая). */
    fun isPage(f: Frame): Boolean {
        val b = orderBand
        if (b != null && AnchorScan.probe(f, b, AnchorScan.ORDER_COLOR)) return true
        rescan(f)
        return orderBand != null
    }

    /** Открыта белая панель ввода текста (клавиатура с полем цены). */
    fun isKeyboard(f: Frame): Boolean = inputBarY(f) != null

    /** Не страница и не поле ввода — считаем, что открыто модальное окно поверх страницы. */
    fun isDialog(f: Frame): Boolean = !isPage(f) && !isKeyboard(f)

    fun orderTap(f: Frame): Pt? = orderBand?.let { Pt(it.cx, it.cy) }
    fun actionTap(f: Frame): Pt? = actionBand?.let { Pt(it.cx, it.cy) }

    fun requestPriceRegion(f: Frame): Rect? = orderBand?.let { AnchorScan.priceRegionLeftOf(it) }
    fun lotPriceRegion(f: Frame): Rect? = actionBand?.let { AnchorScan.priceRegionLeftOf(it) }

    /** Быстрый отпечаток области цены запроса — чтобы не гонять OCR, пока число не поменялось. */
    fun requestHash(f: Frame): Int? = requestPriceRegion(f)?.let { regionHash(f, it) }

    fun regionHash(f: Frame, r: Rect): Int {
        var hash = 17
        var y = r.top
        while (y < r.bottom) {
            var x = r.left
            while (x < r.right) {
                val c = f.bmp.getPixel(x.coerceIn(0, f.w - 1), y.coerceIn(0, f.h - 1))
                val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                hash = hash * 31 + (lum shr 5)
                x += 2
            }
            y += 2
        }
        return hash
    }

    /** Центр белой панели ввода по вертикали в пикселях экрана или null, если её нет. */
    fun inputBarY(f: Frame): Int? {
        val x = (f.w * 0.25f).toInt().coerceIn(0, f.w - 1)
        var first = -1
        var last = -1
        var y = 0
        while (y < f.h) {
            val c = f.bmp.getPixel(x, y)
            val white = Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
            if (white) {
                if (first < 0) first = y
                last = y
            } else if (first >= 0 && y - last > 12) {
                break
            }
            y += 3
        }
        return if (first >= 0 && last - first > f.h * 0.03f) (first + last) / 2 else null
    }
}
