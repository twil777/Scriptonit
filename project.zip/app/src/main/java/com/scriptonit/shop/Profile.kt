package com.scriptonit.shop

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect

data class Pt(val x: Int, val y: Int)

/**
 * Профиль экрана маркета Standoff 2. Снят на экране 2412×1084 (альбом).
 * На другом разрешении все точки и области пересчитываются пропорционально (автонастройка).
 */
object Profile {
    const val REF_W = 2412
    const val REF_H = 1084

    // Области чтения цен (число без значка G)
    val REQUEST_PRICE = Rect(1600, 160, 2010, 212)
    val LOT_PRICE = Rect(1600, 482, 2010, 533)

    // Кнопки
    val ORDER_PAGE = Pt(2223, 187)     // «Заказать» на странице предмета
    val PRICE_FIELD = Pt(1158, 444)    // поле цены в окне запроса
    val DIALOG_ORDER = Pt(1206, 760)   // «Заказать» в окне запроса
    val DIALOG_CLOSE = Pt(1813, 286)   // крестик окна запроса
    val CANCEL = Pt(2223, 300)         // отмена своего запроса (уточнить по скрину)

    // Контрольные точки для определения экрана
    private val ORDER_PROBE = Pt(2100, 165)
    private val DIALOG_PROBE = Pt(1100, 740)
    private val KEYBOARD_PROBE = Pt(500, 450)

    fun mapX(b: Bitmap, x: Int) = (x.toLong() * b.width / REF_W).toInt().coerceIn(0, b.width - 1)
    fun mapY(b: Bitmap, y: Int) = (y.toLong() * b.height / REF_H).toInt().coerceIn(0, b.height - 1)

    fun scaled(b: Bitmap, r: Rect): Rect = Rect(
        mapX(b, r.left), mapY(b, r.top),
        mapX(b, r.right).coerceAtLeast(mapX(b, r.left) + 1), mapY(b, r.bottom).coerceAtLeast(mapY(b, r.top) + 1)
    )

    private fun px(b: Bitmap, p: Pt): Int = b.getPixel(mapX(b, p.x), mapY(b, p.y))

    private fun bright(c: Int) = Color.red(c) > 200 && Color.green(c) in 120..215 && Color.blue(c) < 120

    /** Страница предмета: кнопка «Заказать» ярко-оранжевая. */
    fun isPage(b: Bitmap) = bright(px(b, ORDER_PROBE))

    /** Окно «Запрос на покупку»: фон затемнён, а кнопка внутри окна яркая. */
    fun isDialog(b: Bitmap): Boolean {
        val top = px(b, ORDER_PROBE)
        return Color.red(top) < 150 && bright(px(b, DIALOG_PROBE))
    }

    /** Открыто поле ввода (белая панель над клавиатурой). */
    fun isKeyboard(b: Bitmap): Boolean {
        val c = px(b, KEYBOARD_PROBE)
        return Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
    }
}
