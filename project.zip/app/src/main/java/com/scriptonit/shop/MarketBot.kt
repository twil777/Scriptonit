package com.scriptonit.shop

import android.accessibilityservice.AccessibilityService
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.Locale
import kotlin.math.abs

data class BotConfig(
    val min: Double,
    val max: Double,
    val step: Double,
    val gap: Double,
    val cancelDelayMs: Long,
    val refreshMs: Long,
    val maxMinutes: Int,
    val maxBids: Int,
    val aggressive: Boolean,
    val matchEqual: Boolean
)

object BotPrefs {
    private const val P = "bot"

    fun raw(c: Context, key: String, def: String): String =
        c.getSharedPreferences(P, Context.MODE_PRIVATE).getString(key, null) ?: def

    fun save(c: Context, values: Map<String, String>) {
        val e = c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }

    fun load(c: Context): BotConfig {
        fun d(k: String, def: String) = raw(c, k, def).replace(',', '.').toDoubleOrNull() ?: def.toDouble()
        return BotConfig(
            min = d("min", "10"),
            max = d("max", "99999"),
            step = d("step", "0.01").coerceAtLeast(0.01),
            gap = d("gap2", "0.01").coerceAtLeast(0.01),
            cancelDelayMs = (d("cancel", "2.5") * 1000).toLong().coerceAtLeast(0),
            refreshMs = (d("refresh", "5") * 1000).toLong().coerceAtLeast(2000),
            maxMinutes = d("minutes", "119").toInt().coerceAtLeast(1),
            maxBids = d("bids", "300").toInt().coerceAtLeast(1),
            aggressive = raw(c, "aggr", "0") == "1",
            matchEqual = raw(c, "equal", "1") == "1"
        )
    }
}

/**
 * Встроенная логика перебива запросов.
 *
 * Цикл: на странице предмета читаем цену первого лота и верхнего запроса (и запоминаем их),
 * открываем окно запроса и остаёмся в поле ввода. Пока запрос не изменился, ничего не делаем.
 * Как только верхний запрос вырос, мгновенно вводим цену на шаг выше и подтверждаем,
 * затем отменяем свой запрос. Раз в refreshMs выходим на страницу, обновляем список
 * (галочка «Только мои запросы») и заново запоминаем лот.
 */
class MarketBot(
    private val svc: ClickService,
    private val grab: ScreenGrabber,
    private val ocr: Ocr,
    private val cfg: BotConfig,
    private val onBid: () -> Unit,
    private val log: (String) -> Unit
) {
    private enum class Screen { PAGE, DIALOG, KEYBOARD, UNKNOWN }

    private var fw = Profile.REF_W
    private var fh = Profile.REF_H

    private var lot: Double? = null        // цена первого лота (помним до следующего обновления)
    private var req: Double? = null        // верхний запрос при последнем чтении страницы
    private var baseReq: Double? = null    // запрос, с которым сравниваем «вырос ли»
    private var refreshedAt = 0L
    private var needRefresh = true
    private var firstRefresh = true
    private var inHold = false
    private var lastHash = 0
    private var lastOcrAt = 0L
    private var lowCount = 0
    private var bids = 0

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    private fun track(f: Frame) {
        fw = f.w
        fh = f.h
    }

    private fun screenOf(f: Frame) = when {
        Profile.isKeyboard(f) -> Screen.KEYBOARD
        Profile.isPage(f) -> Screen.PAGE
        Profile.isDialog(f) -> Screen.DIALOG
        else -> Screen.UNKNOWN
    }

    private suspend fun tap(p: Pt) {
        tapPx(p.x * fw / Profile.REF_W.toFloat(), p.y * fh / Profile.REF_H.toFloat())
    }

    private suspend fun tapPx(x: Float, y: Float) {
        svc.gesture(x, y, x, y, 30)
        delay(15)
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (Frame) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (cond(f)) return true
            }
            delay(8)
        }
        return false
    }

    // ---------- клавиатура ----------

    private suspend fun typeText(text: String): Boolean =
        withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.replaceText(text) == true }

    private suspend fun imeDone() {
        val ok = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.done() == true }
        if (!ok) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    /** Закрывает поле ввода. Если «Готово» не сработало, жмёт OK на белой панели. */
    private suspend fun closeKeyboard(): Boolean {
        imeDone()
        if (waitFor(600) { !Profile.isKeyboard(it) }) return true
        var barY: Int? = null
        waitFor(300) { fr -> barY = Profile.inputBarY(fr); barY != null }
        val y = barY
        if (y != null) tapPx(Profile.OK_BAR_X * fw / Profile.REF_W.toFloat(), y.toFloat())
        return waitFor(700) { !Profile.isKeyboard(it) }
    }

    // ---------- вход и выход из режима ожидания ----------

    private suspend fun enterHold(price: Double): Boolean {
        tap(Profile.ORDER_PAGE)
        if (!waitFor(1500) { Profile.isDialog(it) || Profile.isKeyboard(it) }) return false
        tap(Profile.PRICE_FIELD)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) return false
        delay(40)
        if (!typeText(fmt(price))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return false
        }
        inHold = true
        lastHash = 0
        lastOcrAt = 0
        return true
    }

    private suspend fun exitHold() {
        closeKeyboard()
        tap(Profile.DIALOG_CLOSE)
        waitFor(1200) { Profile.isPage(it) }
        inHold = false
    }

    // ---------- чтение страницы ----------

    private suspend fun refreshPage(): Boolean {
        if (!firstRefresh) {
            tap(Profile.MY_REQUESTS)
            delay(140)
            tap(Profile.MY_REQUESTS)
            delay(220)
        }
        var prevR: Double? = null
        var prevL: Double? = null
        val end = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(8); continue }
            track(f)
            if (!Profile.isPage(f)) { delay(20); continue }
            val r = ocr.readPrice(f, Profile.REQUEST_PRICE)
            val l = ocr.readPrice(f, Profile.LOT_PRICE)
            if (r != null && l != null) {
                // принимаем только два одинаковых чтения подряд
                if (prevR != null && prevL != null && abs(prevR - r) < 0.001 && abs(prevL - l) < 0.001) {
                    req = r
                    lot = l
                    refreshedAt = System.currentTimeMillis()
                    log("Лот ${fmt(l)} · запрос ${fmt(r)}")
                    return true
                }
                prevR = r
                prevL = l
            }
            delay(20)
        }
        return false
    }

    /**
     * Выбор цены ставки при новом верхнем запросе r. Возвращает null, если ставить нельзя.
     * Потолок = запомненный лот минус gap, так что фуллпрайса (ставка >= лот) быть не может.
     * Обычно: r + шаг. Если на шаг перебить уже нельзя, а r сам в безопасной зоне, и включён
     * «равный запрос», ставим ровно r. Режим «агрессивно» ставит сразу на потолок.
     */
    private fun chooseBid(r: Double): Double? {
        val l = lot ?: return null
        if (l < cfg.min || l > cfg.max) return null
        val ceiling = round2(l - cfg.gap)
        val outbid = round2(r + cfg.step)
        val bid = when {
            outbid <= ceiling -> if (cfg.aggressive) ceiling else outbid
            cfg.matchEqual && r <= ceiling -> round2(r)
            else -> return null
        }
        return if (bid > cfg.max) null else bid
    }

    // ---------- ставка ----------

    /** Мы в поле ввода: вводим цену, подтверждаем, ждём и отменяем свой запрос. */
    private suspend fun bidFromHold(bid: Double) {
        inHold = false
        needRefresh = true
        baseReq = null
        if (!typeText(fmt(bid))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return
        }
        if (!closeKeyboard()) return
        if (!waitFor(800) { Profile.isDialog(it) }) return
        tap(Profile.DIALOG_ORDER)
        bids++
        onBid()
        log("#$bids: ${fmt(bid)} G · лот ${fmt(lot ?: 0.0)}")
        if (cfg.cancelDelayMs > 0) {
            delay(cfg.cancelDelayMs)
            tap(Profile.CANCEL)
        }
        waitFor(1500) { Profile.isPage(it) }
    }

    private suspend fun pageTick() {
        inHold = false
        val now = System.currentTimeMillis()
        if (needRefresh || now - refreshedAt >= cfg.refreshMs) {
            if (!refreshPage()) { delay(100); return }
            needRefresh = false
            firstRefresh = false
            val r = req ?: return
            val base = baseReq
            baseReq = r
            if (base != null && r > base + 0.001) {
                val bid = chooseBid(r)
                if (bid != null) {
                    if (enterHold(bid)) bidFromHold(bid)
                    return
                }
                log("Пропуск: запрос ${fmt(r)} вплотную к лоту ${fmt(lot ?: 0.0)}")
            }
        }
        val r = baseReq ?: req ?: return
        if (!enterHold(round2(r + cfg.step))) delay(150)
    }

    private suspend fun holdTick(f: Frame?) {
        val now = System.currentTimeMillis()
        if (now - refreshedAt >= cfg.refreshMs) {
            exitHold()
            needRefresh = true
            return
        }
        if (f == null) return
        val hash = Profile.regionHash(f, Profile.REQUEST_PRICE)
        if (hash == lastHash && now - lastOcrAt < 600) return
        lastHash = hash
        lastOcrAt = now
        val r = ocr.readPrice(f, Profile.REQUEST_PRICE) ?: return
        val base = baseReq
        if (base == null) {
            baseReq = r
            return
        }
        if (r > base + 0.001) {
            baseReq = r
            lowCount = 0
            val bid = chooseBid(r)
            if (bid != null) {
                bidFromHold(bid)
            } else {
                log("Пропуск: запрос ${fmt(r)} вплотную к лоту ${fmt(lot ?: 0.0)}")
            }
        } else if (r < base - 0.001) {
            lowCount++
            if (lowCount >= 2) {
                baseReq = r
                lowCount = 0
            }
        } else {
            lowCount = 0
        }
    }

    suspend fun run() {
        val start = System.currentTimeMillis()
        val limitMs = cfg.maxMinutes * 60_000L
        var screen = Screen.UNKNOWN
        var lost = 0
        log("Работаю…")

        while (true) {
            yield()
            if (System.currentTimeMillis() - start >= limitMs) { log("Время работы вышло"); break }
            if (bids >= cfg.maxBids) { log("Лимит ставок: $bids"); break }

            val f = grab.frame()
            if (f != null) {
                track(f)
                screen = screenOf(f)
            }

            when (screen) {
                Screen.KEYBOARD -> {
                    lost = 0
                    if (inHold) {
                        holdTick(f)
                    } else {
                        exitHold()
                        needRefresh = true
                    }
                }
                Screen.PAGE -> {
                    lost = 0
                    pageTick()
                }
                Screen.DIALOG -> {
                    lost = 0
                    inHold = false
                    tap(Profile.DIALOG_CLOSE)
                    delay(350)
                }
                Screen.UNKNOWN -> {
                    lost++
                    if (lost > 400) { log("Открой страницу предмета в маркете"); break }
                    delay(15)
                }
            }
            delay(4)
        }
    }
}
