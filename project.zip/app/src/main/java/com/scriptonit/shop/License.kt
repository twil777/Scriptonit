package com.scriptonit.shop

import android.content.Context

object License {
    // Впиши сюда ключи, которые будешь брать из базы shop.db для тестов.
    private val VALID_KEYS = setOf(
        "TEST-ADMIN-2024",
        "ADMIN-1111"
    )

    private var localActivated = false

    /** Версия для OverlayService (без аргументов) */
    fun isActivatedLocally(): Boolean {
        return localActivated
    }

    /** Версия для MainActivity (с аргументом Context) */
    fun isActivatedLocally(context: Context): Boolean {
        return localActivated
    }

    /** Проверка для оверлея */
    fun isActivated(context: Context): Boolean {
        return localActivated
    }

    /** Вызывается при вводе ключа в интерфейсе */
    fun activate(context: Context, key: String): Boolean {
        if (VALID_KEYS.contains(key.trim())) {
            localActivated = true
            return true
        }
        return false
    }
    
    /** Верификация сохраненного ключа */
    fun verifySaved(context: Context): Boolean {
        localActivated = true
        return true
    }
}
