package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/** Быстрый захват кадров экрана через MediaProjection. */
class ScreenGrabber(private val ctx: Context, private val projection: MediaProjection) {
    private val handler = Handler(Looper.getMainLooper())
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var w = 0
    private var h = 0

    init {
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                release()
            }
        }, handler)
    }

    @Suppress("DEPRECATION")
    private fun ensure() {
        val dm = DisplayMetrics()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        if (reader != null && dm.widthPixels == w && dm.heightPixels == h) return
        w = dm.widthPixels
        h = dm.heightPixels
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val d = display
        if (d == null) {
            display = projection.createVirtualDisplay(
                "scriptonit", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, newReader.surface, null, handler
            )
        } else {
            d.resize(w, h, dm.densityDpi)
            d.surface = newReader.surface
        }
        reader?.close()
        reader = newReader
    }

    /** Последний новый кадр или null, если нового пока нет. Битмап нужно освободить через recycle(). */
    fun frame(): Bitmap? {
        ensure()
        val img = reader?.acquireLatestImage() ?: return null
        try {
            if (img.width != w || img.height != h) return null
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPixels, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            if (rowPixels == w) return full
            val cropped = Bitmap.createBitmap(full, 0, 0, w, h)
            full.recycle()
            return cropped
        } finally {
            img.close()
        }
    }

    fun release() {
        try { display?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        display = null
        reader = null
    }
}
