package com.scriptonit.shop

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

/**
 * Собственная клавиатура. В числовых полях показывает крупный цифровой блок.
 * Бот вводит цену напрямую через replaceText(), без тапов по клавишам.
 */
class ScriptoKeyboardService : InputMethodService() {

    companion object {
        @Volatile
        var instance: ScriptoKeyboardService? = null
    }

    private var russian = false
    private var shift = false
    private var numeric = false
    private lateinit var container: LinearLayout

    private val en = listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val ru = listOf("1234567890", "йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF060D09.toInt())
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        render()
        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        if (::container.isInitialized) render()
    }

    /** Полностью заменяет текст в поле. Вызывать на главном потоке. */
    fun replaceText(text: String): Boolean {
        val ic = currentInputConnection ?: return false
        ic.beginBatchEdit()
        ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText("", 1)
        ic.deleteSurroundingText(64, 64)
        ic.commitText(text, 1)
        ic.endBatchEdit()
        return true
    }

    /** Подтверждает ввод (аналог «Готово»). Вызывать на главном потоке. */
    fun done(): Boolean {
        val ic = currentInputConnection ?: return false
        ic.performEditorAction(EditorInfo.IME_ACTION_DONE)
        return true
    }

    private fun key(
        label: String,
        weight: Float = 1f,
        accent: Boolean = false,
        height: Int = 46,
        size: Float = 17f,
        onClick: () -> Unit
    ): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = size
        typeface = Typeface.DEFAULT_BOLD
        minWidth = 0
        minimumWidth = 0
        setPadding(0, 0, 0, 0)
        setTextColor(if (accent) 0xFF03130A.toInt() else 0xFFD5FBE2.toInt())
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (accent) 0xFF22C55E.toInt() else 0xFF12261A.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(0, dp(height), weight).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        }
        setOnClickListener { onClick() }
    }

    private fun row(vararg keys: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        keys.forEach { addView(it) }
    }

    private fun type(ch: String) {
        currentInputConnection?.commitText(if (shift) ch.uppercase() else ch, 1)
        if (shift) {
            shift = false
            render()
        }
    }

    private fun render() {
        container.removeAllViews()
        if (numeric) renderNumeric() else renderText()
    }

    private fun renderNumeric() {
        val h = 54
        val s = 22f
        listOf("123", "456", "789").forEach { line ->
            container.addView(row(*line.map { c -> key(c.toString(), height = h, size = s) { type(c.toString()) } }.toTypedArray()))
        }
        container.addView(
            row(
                key(".", height = h, size = s) { type(".") },
                key("0", height = h, size = s) { type("0") },
                key("⌫", height = h, size = s) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) }
            )
        )
        container.addView(row(key("Готово", accent = true, height = h, size = 18f) { done() }))
    }

    private fun renderText() {
        val layout = if (russian) ru else en
        for (line in layout) {
            val keys = line.map { c ->
                val s = c.toString()
                key(if (shift) s.uppercase() else s) { type(s) }
            }
            container.addView(row(*keys.toTypedArray()))
        }
        container.addView(
            row(
                key(if (shift) "⇧" else "⬆", 1.3f, accent = shift) { shift = !shift; render() },
                key(if (russian) "RU" else "EN", 1.3f) { russian = !russian; render() },
                key(",") { type(",") },
                key("пробел", 4f) { currentInputConnection?.commitText(" ", 1) },
                key(".") { type(".") },
                key("⌫", 1.3f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) },
                key("⏎", 1.3f, accent = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }
            )
        )
    }
}
