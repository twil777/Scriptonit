package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Чтение цены с кадра экрана. */
class Ocr(ctx: Context) {
    private val tess = TessBaseAPI()
    val ready: Boolean

    init {
        var ok = false
        try {
            ok = hasData(ctx) && tess.init(ctx.filesDir.absolutePath, "eng")
            if (ok) {
                tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE)
                tess.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "0123456789.,")
            }
        } catch (e: Exception) {
            ok = false
        }
        ready = ok
    }

    fun close() {
        try { tess.recycle() } catch (e: Exception) { }
    }

    /** Возвращает цену вида 61999.97 или null, если распознать не удалось. */
    fun readPrice(frame: Bitmap, region: Rect): Double? {
        if (!ready) return null
        val r = Profile.scaled(frame, region)
        val crop = Bitmap.createBitmap(frame, r.left, r.top, r.width(), r.height())
        val k = 2
        val scaled = Bitmap.createScaledBitmap(crop, crop.width * k, crop.height * k, true)
        crop.recycle()
        val w = scaled.width
        val h = scaled.height
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        scaled.recycle()
        for (i in px.indices) {
            val c = px[i]
            val lum = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
            px[i] = if (lum > 128) Color.BLACK else Color.WHITE
        }
        val pad = 24
        val out = Bitmap.createBitmap(w + pad * 2, h + pad * 2, Bitmap.Config.ARGB_8888)
        Canvas(out).drawColor(Color.WHITE)
        out.setPixels(px, 0, w, pad, pad, w, h)
        return try {
            tess.setImage(out)
            parsePrice(tess.getUTF8Text() ?: "")
        } catch (e: Exception) {
            null
        } finally {
            out.recycle()
        }
    }

    companion object {
        private const val URL_ENG = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata"

        fun dataFile(ctx: Context) = File(File(ctx.filesDir, "tessdata"), "eng.traineddata")

        fun hasData(ctx: Context): Boolean = dataFile(ctx).let { it.exists() && it.length() > 1_000_000 }

        /** Скачивает языковые данные (один раз, около 4 МБ). */
        fun download(ctx: Context): Boolean {
            return try {
                val f = dataFile(ctx)
                f.parentFile?.mkdirs()
                val tmp = File(f.parentFile, "eng.tmp")
                val conn = URL(URL_ENG).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                if (tmp.length() > 1_000_000) tmp.renameTo(f) else { tmp.delete(); false }
            } catch (e: Exception) {
                false
            }
        }

        fun parsePrice(raw: String): Double? {
            var s = raw.replace(',', '.').filter { it.isDigit() || it == '.' }.trim('.')
            if (s.isEmpty()) return null
            if (!s.contains('.')) {
                if (s.length < 3) return null
                s = s.dropLast(2) + "." + s.takeLast(2)   // у цен в маркете всегда 2 знака после точки
            }
            if (!Regex("^\\d{1,6}\\.\\d{2}$").matches(s)) return null
            return s.toDoubleOrNull()
        }
    }
}
