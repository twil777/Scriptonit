package com.scriptonit.shop

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.Locale
import kotlin.math.abs

data class BotConfig(
    val min: Double,
    val max: Double,
    val step: Double,
    val cancelDelayMs: Long,
    val maxMinutes: Int,
    val maxBids: Int,
    val cooldownMs: Long = 1500
)

object BotPrefs {
    private const val P = "bot"

    fun raw(c: Context, key: String, def: String): String =
        c.getSharedPreferences(P, Context.MODE_PRIVATE).getString(key, null) ?: def

    fun save(c: Context, values: Map<String, String>) {
        val e = c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }

    fun load(c: Context): BotConfig {
        fun d(k: String, def: String) = raw(c, k, def).replace(',', '.').toDoubleOrNull() ?: def.toDouble()
        return BotConfig(
            min = d("min", "10"),
            max = d("max", "99999"),
            step = d("step", "0.01").coerceAtLeast(0.01),
            cancelDelayMs = (d("cancel", "2.5") * 1000).toLong().coerceAtLeast(0),
            maxMinutes = d("minutes", "119").toInt().coerceAtLeast(1),
            maxBids = d("bids", "300").toInt().coerceAtLeast(1)
        )
    }
}

/**
 * Встроенная логика перебива запросов на странице предмета.
 * Цены читаются с экрана, затем ставится запрос на шаг выше, через паузу он отменяется.
 */
class MarketBot(
    private val svc: ClickService,
    private val grab: ScreenGrabber,
    private val ocr: Ocr,
    private val cfg: BotConfig,
    private val log: (String) -> Unit
) {
    private var fw = Profile.REF_W
    private var fh = Profile.REF_H

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)

    private fun track(f: Bitmap) {
        fw = f.width
        fh = f.height
    }

    private suspend fun tap(p: Pt) {
        val x = p.x * fw / Profile.REF_W.toFloat()
        val y = p.y * fh / Profile.REF_H.toFloat()
        svc.gesture(x, y, x, y, 40)
        delay(20)
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (Bitmap) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                val ok = cond(f)
                f.recycle()
                if (ok) return true
            }
            delay(30)
        }
        return false
    }

    private suspend fun imeDone() {
        val ok = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.done() == true }
        if (!ok) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    private suspend fun recover(dialog: Boolean, keyboard: Boolean) {
        when {
            keyboard -> { imeDone(); delay(350) }
            dialog -> { tap(Profile.DIALOG_CLOSE); delay(450) }
            else -> delay(120)
        }
    }

    private suspend fun placeBid(price: Double): Boolean {
        tap(Profile.ORDER_PAGE)
        if (!waitFor(1500) { Profile.isDialog(it) }) return false

        tap(Profile.PRICE_FIELD)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) return false
        delay(80)

        val ok = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.replaceText(fmt(price)) == true }
        if (!ok) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return false
        }
        imeDone()
        waitFor(1000) { !Profile.isKeyboard(it) }
        delay(100)

        tap(Profile.DIALOG_ORDER)
        if (cfg.cancelDelayMs > 0) {
            delay(cfg.cancelDelayMs)
            tap(Profile.CANCEL)
        }
        waitFor(1500) { Profile.isPage(it) }
        return true
    }

    suspend fun run() {
        val start = System.currentTimeMillis()
        val limitMs = cfg.maxMinutes * 60_000L
        var lastReq = 0.0
        var lowCount = 0
        var bids = 0
        var lastBid = 0L
        var lost = 0
        log("Работаю…")

        while (true) {
            yield()
            val now = System.currentTimeMillis()
            if (now - start >= limitMs) { log("Время работы вышло"); break }
            if (bids >= cfg.maxBids) { log("Лимит ставок: $bids"); break }

            val f = grab.frame()
            if (f == null) { delay(25); continue }
            track(f)

            if (!Profile.isPage(f)) {
                val dialog = Profile.isDialog(f)
                val keyboard = Profile.isKeyboard(f)
                f.recycle()
                lost++
                if (lost > 80) { log("Открой страницу предмета в маркете"); break }
                recover(dialog, keyboard)
                continue
            }
            lost = 0

            if (now - lastBid < cfg.cooldownMs) { f.recycle(); delay(50); continue }

            val req = ocr.readPrice(f, Profile.REQUEST_PRICE)
            val lot = ocr.readPrice(f, Profile.LOT_PRICE)
            f.recycle()
            if (req == null || lot == null) { delay(50); continue }

            // база следует вниз только после трёх чтений подряд (защита от ошибок распознавания)
            if (lastReq > 0 && req < lastReq - 0.001) {
                lowCount++
                if (lowCount >= 3) { lastReq = req; lowCount = 0 }
            } else {
                lowCount = 0
            }

            val increased = lastReq > 0 && req > lastReq + 0.001
            val gapOk = lot - req > cfg.step + 0.001
            val inRange = lot >= cfg.min && lot <= cfg.max

            if (increased && gapOk && inRange) {
                val f2 = grab.frame()
                if (f2 == null) { delay(20); continue }
                track(f2)
                val req2 = ocr.readPrice(f2, Profile.REQUEST_PRICE)
                val lot2 = ocr.readPrice(f2, Profile.LOT_PRICE)
                f2.recycle()
                val stable = req2 != null && lot2 != null &&
                    abs(req2 - req) < 0.001 && abs(lot2 - lot) < 0.001 &&
                    lot2 - req2 > cfg.step + 0.001
                if (!stable) { delay(20); continue }

                val bid = Math.round((req + cfg.step) * 100.0) / 100.0
                if (placeBid(bid)) {
                    bids++
                    lastReq = bid
                    lastBid = System.currentTimeMillis()
                    log("#$bids: ${fmt(bid)} G (лот ${fmt(lot)})")
                } else {
                    log("Не удалось поставить запрос")
                    delay(300)
                }
            } else {
                if (lastReq == 0.0) lastReq = req
                delay(50)
            }
        }
    }
}
