package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs

/**
 * Поиск элементов интерфейса по цвету, без привязки к конкретному разрешению или
 * раскладке экрана. Работает одинаково на телефоне и на ПК-клиенте: кнопка «Заказать»
 * и синие кнопки «Купить»/«Отмена» в Standoff 2 имеют один и тот же цвет независимо
 * от размера окна, меняется только их положение и масштаб.
 */
object AnchorScan {
    data class Band(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
        val w get() = x1 - x0
        val h get() = y1 - y0
        val cx get() = (x0 + x1) / 2
        val cy get() = (y0 + y1) / 2
    }

    val ORDER_COLOR = Triple(242, 163, 52)   // кнопка «Заказать»
    val ACTION_COLOR = Triple(131, 154, 202) // кнопки «Купить» / «Отмена»
    private const val TOL = 46

    private fun matches(c: Int, t: Triple<Int, Int, Int>): Boolean {
        val d = abs(Color.red(c) - t.first) + abs(Color.green(c) - t.second) + abs(Color.blue(c) - t.third)
        return d < TOL
    }

    /** Ищет сплошной цветовой блок нужного цвета в заданной области кадра (или во всём кадре). */
    fun scan(frame: Frame, target: Triple<Int, Int, Int>, step: Int = 4, region: Rect? = null): Band? {
        val bmp = frame.bmp
        val rx0 = (region?.left ?: 0).coerceIn(0, frame.w - 1)
        val ry0 = (region?.top ?: 0).coerceIn(0, frame.h - 1)
        val rx1 = (region?.right ?: frame.w).coerceIn(rx0 + 1, frame.w)
        val ry1 = (region?.bottom ?: frame.h).coerceIn(ry0 + 1, frame.h)

        var minX = Int.MAX_VALUE
        var minY = Int.MAX_VALUE
        var maxX = -1
        var maxY = -1
        var count = 0
        var y = ry0
        while (y < ry1) {
            var x = rx0
            while (x < rx1) {
                if (matches(bmp.getPixel(x, y), target)) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    count++
                }
                x += step
            }
            y += step
        }
        if (count < 30) return null
        val w = maxX - minX
        val h = maxY - minY
        // отсекаем шум/случайные совпадения: кнопка не может быть точкой или во весь экран
        if (w < frame.w * 0.03f || w > frame.w * 0.38f) return null
        if (h < frame.h * 0.012f || h > frame.h * 0.2f) return null
        return Band(minX, minY, maxX, maxY)
    }

    /** Кнопка такого же вида сразу под указанной (тот же цвет, похожая ширина, ниже по кадру). */
    fun scanBelow(frame: Frame, target: Triple<Int, Int, Int>, above: Band, maxGapPx: Int, step: Int = 4): Band? {
        val pad = above.w / 6
        val region = Rect(above.x0 - pad, above.y1, above.x1 + pad, (above.y1 + maxGapPx).coerceAtMost(frame.h))
        return scan(frame, target, step, region)
    }

    fun probe(frame: Frame, band: Band, target: Triple<Int, Int, Int>): Boolean =
        band.cx in 0 until frame.w && band.cy in 0 until frame.h && matches(frame.bmp.getPixel(band.cx, band.cy), target)

    /** Полоса с ценой слева от кнопки: соотношение выведено из реальных скриншотов игры и не зависит от разрешения. */
    fun priceRegionLeftOf(button: Band): Rect {
        val l = (button.x0 - button.w * 0.58f).toInt()
        val r = (button.x0 - button.w * 0.03f).toInt()
        return Rect(l.coerceAtLeast(0), button.y0, r.coerceAtLeast(l + 10), button.y1)
    }
}
