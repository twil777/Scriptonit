package com.scriptonit.shop

import android.content.Context
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Клиент активации. Сервер — источник истины: ключ привязывается к одному device_id
 * навсегда (activate), а verify лишь подтверждает, что эта привязка ещё в силе.
 * В приложении хранится только собственный ключ пользователя — никакой базы ключей
 * здесь нет и не может быть, поэтому разобрать APK и достать чужие ключи нельзя:
 * их просто негде хранить на телефоне.
 */
object License {
    private const val P = "license"

    /** Адрес твоего license_server.py (за HTTPS-прокси). Пример: "https://scriptonit.example.com" */
    var SERVER_URL = "https://bot-1792778425-7298-twil.bothost.tech"

    fun deviceId(ctx: Context): String =
        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"

    fun savedKey(ctx: Context): String? =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("key", null)

    fun isActivatedLocally(ctx: Context): Boolean = savedKey(ctx) != null

    private fun post(path: String, key: String, deviceId: String): Boolean {
        return try {
            val conn = URL(SERVER_URL.trimEnd('/') + path).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("key", key).put("device_id", deviceId).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val text = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                .bufferedReader().use { it.readText() }
            JSONObject(text).optBoolean("ok", false)
        } catch (e: Exception) {
            false
        }
    }

    /** Активирует ключ на этом устройстве. При успехе сохраняет его локально. */
    fun activate(ctx: Context, key: String): Boolean {
        val k = key.trim().uppercase()
        val ok = post("/activate", k, deviceId(ctx))
        if (ok) ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("key", k).apply()
        return ok
    }

    /** Повторная проверка уже сохранённого ключа. Вызывать при запуске и периодически. */
    fun verifySaved(ctx: Context): Boolean {
        val k = savedKey(ctx) ?: return false
        return post("/verify", k, deviceId(ctx))
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
