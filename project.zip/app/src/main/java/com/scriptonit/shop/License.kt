package com.scriptonit.shop

import android.content.Context
import android.content.SharedPreferences

object License {
    private const val PREFS_NAME = "license_prefs"
    private const val KEY_LICENSE = "license_key"
    
    // Впиши сюда те ключи, которые у тебя лежат в базе shop.db (или те, которые выдаст бот).
    // В будущем, если захочешь, сможешь заменить это на реальный запрос к серверу.
    private val VALID_KEYS = setOf(
        "TEST-ADMIN-2024",
        "ADMIN-1111",
        "ADMIN-2222"
        // добавь сюда ключи из базы
    )

    fun getKey(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LICENSE, null)
    }

    fun activate(context: Context, key: String): Boolean {
        // Если ключ есть в нашем списке валидных
        if (VALID_KEYS.contains(key.trim())) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putString(KEY_LICENSE, key.trim()).apply()
            return true
        }
        return false
    }

    fun isActivated(context: Context): Boolean {
        val key = getKey(context) ?: return false
        return VALID_KEYS.contains(key)
    }
    
    fun logout(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_LICENSE).apply()
    }
}
