package com.scriptonit.shop

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield

class ScriptRunner {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    val running: Boolean get() = job?.isActive == true

    fun start(svc: ClickService, script: Script, screenW: Int, screenH: Int, onDone: () -> Unit) {
        stop()
        val (sx, sy) = Scaling.factors(script, screenW, screenH)
        job = scope.launch {
            try {
                run(svc, script.cmds, sx, sy)
            } finally {
                onDone()
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    private suspend fun run(svc: ClickService, cmds: List<Cmd>, sx: Float, sy: Float) {
        for (c in cmds) {
            yield() // точка отмены, чтобы «Стоп» срабатывал сразу
            when (c) {
                is Cmd.Tap -> {
                    svc.gesture(c.x * sx, c.y * sy, c.x * sx, c.y * sy, 40)
                    delay(20)
                }
                is Cmd.Swipe -> {
                    svc.gesture(c.x1 * sx, c.y1 * sy, c.x2 * sx, c.y2 * sy, c.ms)
                    delay(20)
                }
                is Cmd.Wait -> delay(c.ms)
                is Cmd.Repeat -> {
                    var i = 0
                    while (c.times <= 0 || i < c.times) {
                        run(svc, c.body, sx, sy)
                        i++
                        yield() // пустое тело loop не должно вешать приложение
                    }
                }
            }
        }
    }
}
