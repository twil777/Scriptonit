package com.scriptonit.shop

import android.content.Context
import java.io.File
import kotlin.math.max
import kotlin.math.min

sealed class Cmd {
    data class Tap(val x: Float, val y: Float) : Cmd()
    data class Swipe(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val ms: Long) : Cmd()
    data class Wait(val ms: Long) : Cmd()
    /** times <= 0 означает бесконечный цикл до остановки. */
    data class Repeat(val times: Int, val body: List<Cmd>) : Cmd()
}

data class Script(val refW: Int, val refH: Int, val cmds: List<Cmd>)

/**
 * Формат скрипта (одна команда на строку, # — комментарий):
 *   ref 2400 1080        опорное разрешение, под которое записаны координаты
 *   tap X Y
 *   swipe X1 Y1 X2 Y2 [мс]
 *   wait МС
 *   repeat N ... end     повторить блок N раз
 *   loop ... end         повторять, пока не нажмёшь стоп
 */
object ScriptParser {
    private class Frame(val list: MutableList<Cmd>, val times: Int)

    fun parse(text: String): Script {
        var refW = 0
        var refH = 0
        val stack = ArrayDeque<Frame>()
        stack.addLast(Frame(mutableListOf(), 1))

        text.lineSequence().forEachIndexed { idx, raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) return@forEachIndexed
            val p = line.split(Regex("\\s+"))
            val n = idx + 1
            try {
                when (p[0].lowercase()) {
                    "ref" -> { refW = p[1].toInt(); refH = p[2].toInt() }
                    "tap" -> stack.last().list.add(Cmd.Tap(p[1].toFloat(), p[2].toFloat()))
                    "swipe" -> stack.last().list.add(
                        Cmd.Swipe(
                            p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), p[4].toFloat(),
                            p.getOrNull(5)?.toLong() ?: 300L
                        )
                    )
                    "wait" -> stack.last().list.add(Cmd.Wait(p[1].toLong()))
                    "repeat" -> stack.addLast(Frame(mutableListOf(), p[1].toInt()))
                    "loop" -> stack.addLast(Frame(mutableListOf(), 0))
                    "end" -> {
                        if (stack.size < 2) throw IllegalArgumentException("лишний end")
                        val f = stack.removeLast()
                        stack.last().list.add(Cmd.Repeat(f.times, f.list))
                    }
                    else -> throw IllegalArgumentException("неизвестная команда «${p[0]}»")
                }
            } catch (e: IndexOutOfBoundsException) {
                throw IllegalArgumentException("Строка $n: не хватает чисел")
            } catch (e: NumberFormatException) {
                throw IllegalArgumentException("Строка $n: неверное число")
            } catch (e: IllegalArgumentException) {
                throw IllegalArgumentException("Строка $n: ${e.message}")
            }
        }
        if (stack.size != 1) throw IllegalArgumentException("Не закрыт блок repeat/loop (нужен end)")
        return Script(refW, refH, stack.last().list)
    }
}

/** Автонастройка: пересчёт координат из опорного разрешения скрипта в реальный экран. */
object Scaling {
    fun factors(s: Script, screenW: Int, screenH: Int): Pair<Float, Float> {
        if (s.refW <= 0 || s.refH <= 0) return 1f to 1f
        val long = max(screenW, screenH)
        val short = min(screenW, screenH)
        val landscape = s.refW >= s.refH
        val tw = if (landscape) long else short
        val th = if (landscape) short else long
        return tw / s.refW.toFloat() to th / s.refH.toFloat()
    }
}

object Store {
    private const val PREFS = "scriptonit"
    private const val DEMO = """# Пример скрипта Scriptonit Shop.
# Замени координаты на свои. ref — разрешение экрана, под которое они записаны:
# на другом экране приложение пересчитает всё само.
ref 2400 1080

wait 500
tap 1200 540
wait 300
swipe 600 800 1800 800 400

repeat 5
    tap 1200 540
    wait 200
end
"""

    fun dir(c: Context): File = File(c.filesDir, "scripts").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        dir(c).listFiles()?.filter { it.extension == "txt" }?.sortedBy { it.name } ?: emptyList()

    fun ensureDemo(c: Context) {
        if (list(c).isEmpty()) File(dir(c), "demo.txt").writeText(DEMO)
    }

    fun selected(c: Context): File? {
        val name = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("script", null)
        return list(c).firstOrNull { it.name == name } ?: list(c).firstOrNull()
    }

    fun select(c: Context, f: File) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("script", f.name).apply()
    }

    /** Проверяет скрипт и сохраняет. Бросает IllegalArgumentException с понятным текстом. */
    fun save(c: Context, rawName: String, text: String): File {
        ScriptParser.parse(text)
        val base = rawName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9А-Яа-я_-]"), "_").ifBlank { "script" }
        val f = File(dir(c), "$base.txt")
        f.writeText(text)
        select(c, f)
        return f
    }
}
