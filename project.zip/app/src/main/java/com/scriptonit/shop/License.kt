package com.scriptonit.shop

import android.content.Context

object License {
    // Впиши сюда ключ который дал @Scriptonit_Shop_bot
    private val VALID_KEYS = setOf(
        "TEST-ADMIN-2024",
        "ADMIN-1111"
    )

    private var localActivated = false

    /** Проверка для интерфейса (MainActivity) */
    fun isActivatedLocally(): Boolean {
        return localActivated
    }

    /** Проверка для оверлея (OverlayService) */
    fun isActivated(context: Context): Boolean {
        return localActivated
    }

    /** Вызывается при вводе ключа в интерфейсе */
    fun activate(context: Context, key: String): Boolean {
        if (VALID_KEYS.contains(key.trim())) {
            localActivated = true
            return true
        }
        return false
    }
    
    /** Верификация сохраненного ключа (когда заходишь в приложение) */
    fun verifySaved(context: Context): Boolean {
        // Для тестов просто возвращаем true, чтобы не блокировать вход.
        // В будущем здесь будет проверка с сервера.
        localActivated = true
        return true
    }
}
